@extends('Admin.layout.adminlayout2')
@section('title', 'Kitchen Dashboard')
@section('content')
    <style>
        span.ord_bage {
            background-color: red;
            padding: 12px;
            color: white;
            font-size: 20px;
            border-radius: 24px;
            position: absolute;
            margin-top: -55px;
            margin-left: 121px;
        }

        .badge {

            width: 80px;
            border-radius: 29px;
            padding: -6px;
            background-color: rgb(179, 226, 9);
            position: absolute;
            margin-left: 78px;
            margin-top: -50px;

        }

        .main-header .navbar-custom-menu {
            //float: right;
            position: absolute;
            margin-left: 257px;
        }

        .btn span.glyphicon {
            opacity: 0;
        }

        .btn.active span.glyphicon {
            opacity: 1;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            border: none;
            position: relative;
            margin-bottom: 30px;
            box-shadow: 0 0.46875rem 2.1875rem rgba(90, 97, 105, 0.1), 0 0.9375rem 1.40625rem rgba(90, 97, 105, 0.1), 0 0.25rem 0.53125rem rgba(90, 97, 105, 0.12), 0 0.125rem 0.1875rem rgba(90, 97, 105, 0.1);
        }

        .l-bg-cherry {
            background: linear-gradient(to right, #493240, #f09) !important;
            color: #fff;
        }

        .l-bg-blue-dark {
            background: linear-gradient(to right, #373b44, #4286f4) !important;
            color: #fff;
        }

        .l-bg-green-dark {
            background: linear-gradient(to right, #0a504a, #38ef7d) !important;
            color: #fff;
        }

        .l-bg-orange-dark {
            background: linear-gradient(to right, #a86008, #ffba56) !important;
            color: #fff;
        }

        .card .card-statistic-3 .card-icon-large .fas,
        .card .card-statistic-3 .card-icon-large .far,
        .card .card-statistic-3 .card-icon-large .fab,
        .card .card-statistic-3 .card-icon-large .fal {
            font-size: 110px;
        }

        .card .card-statistic-3 .card-icon {
            text-align: center;
            line-height: 50px;
            margin-left: 15px;
            color: #000;
            position: absolute;
            right: -5px;
            top: 20px;
            opacity: 0.1;
        }

        .l-bg-cyan {
            background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
            color: #fff;
        }

        .l-bg-green {
            background: linear-gradient(135deg, #23bdb8 0%, #43e794 100%) !important;
            color: #fff;
        }

        .l-bg-orange {
            background: linear-gradient(to right, #f9900e, #ffba56) !important;
            color: #fff;
        }

        .l-bg-cyan {
            background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
            color: #fff;
        }

    </style>
    <div class="container">
        <div class="row" style="float:right">
            <div class="col-md-12">
                <p style="font-size: 24px;">New Order </p><span class="ord_bage" id="blink">11</span></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <h4 class="text-center mt-50">WelCome To Kitchen Dashboard</h4>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1"
                        value="option1" />
                    <label class="form-check-label l-bg-green" for="inlineRadio1"
                        style="font-size: 22px;border-radius: 8px;padding: 32px;">Delivered</label>
                </div>

                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2"
                        value="option2" />
                    <label class="form-check-label l-bg-cyan" for="inlineRadio2"
                        style="font-size: 22px;border-radius: 8px;padding: 32px;">New Orderd</label>
                </div>

                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3"
                        value="option3" />
                    <label class="form-check-label l-bg-orange" for="inlineRadio3"
                        style="font-size: 22px;border-radius: 8px;padding: 32px;">Prepareing</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio4"
                        value="option4" />
                    <label class="form-check-label l-bg-cherry" for="inlineRadio4"
                        style="font-size: 22px;border-radius: 8px;padding: 32px;">Ready </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio5"
                        value="option5" />
                    <label class="form-check-label bg-danger" for="inlineRadio5"
                        style="font-size: 22px;border-radius: 8px;padding: 32px;">Canceled</label>
                </div>
            </div>
        </div>


    </div>
    <h2 class="divider donotcross" contenteditable>All Order Listings</h2>
    <div class="container" style="margin-top:40px;">
        <div class="row">
            <div class="col-md-12 ">
                <div class="row ">
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-green">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-orange">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cyan">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-green">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-orange">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cyan">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-green">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-orange">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cyan">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-6">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <div class="badge">
                                        <p
                                            style="margin-left: 8px;color: #0c1a32;margin-top: 14px;font-size: 13px;font-weight: 700;">
                                            10:40 AM</p>
                                    </div>
                                    <p class="card-title mb-0">Order Id 129086786</p>
                                </div>

                                <select class="form-control">
                                    <option>Accept</option>
                                    <option>Processing</option>
                                    <option>delivery</option>
                                    <option>Cancel</option>
                                </select>
                                <br>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#myModal">
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content" style="width: 763px;content: center;margin-left: -103px;">

                <!-- Modal Header -->
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p>Order Id :14568676</p>
                    <p>Order Time : 10:40 AM</p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>SL.NO</th>
                                    <th>Item</th>
                                    <th>Addons</th>
                                    <th>qty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td><img src="{{ url('/') }}/storage/app/menu_image/biriyani.jpg"
                                            style="height: 89px;border-radius: 46px;width: 89px;"><br>Chicken roll</td>
                                    <td><span style="font-size: 23px;">N/A</span></td>
                                    <td><span style="font-size: 23px;">2</span></td>
                                </tr>
                                <tr>
                                    <td>2</td>

                                    <td><img src="{{ url('/') }}/storage/app/menu_image/biriyani.jpg"
                                            style="height: 89px;border-radius: 46px;width: 89px;"><br>Briyani</td>
                                    <td><img src="{{ url('/') }}/storage/app/menu_image/cocacola.png"
                                            style="height: 89px;width: 89px;"><span style="font-size:23px;">+</span><img
                                            src="{{ url('/') }}/storage/app/menu_image/salad.png"
                                            style="height: 89px;width: 89px;"><span style="font-size:23px;">+</span><img
                                            src="{{ url('/') }}/storage/app/menu_image/89x89.png"
                                            style="height: 89px;width: 89px;"></td>
                                    <td><span style="font-size: 23px;">2</span></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                </div>

                @push('scripts')
                    <script type="text/javascript">
                        var blink = document.getElementById('blink');
                        setInterval(function() {
                            blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
                        }, 500);
                    </script>
                @endpush

            @endsection

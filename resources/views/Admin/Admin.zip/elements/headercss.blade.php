

        <link rel="icon" href="https://riday-admin-template.multipurposethemes.com/bs5/images/favicon.ico">

        <title>Riday - Restaurant Bootstrap Admin Template Webapp</title>

        <!-- Vendors Style-->
        <link rel="stylesheet" href="{{url('/')}}/Admintheme/assets/css/vendors_css.css">

        <!-- Style-->
        <link rel="stylesheet" href="{{url('/')}}/Admintheme/assets/css/style.css">
        <link rel="stylesheet" href="{{url('/')}}/Admintheme/assets/css/skin_color.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    .sidebar-widgets {
        display: none;
    }
</style>

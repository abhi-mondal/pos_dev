
     <script src="{{url('/')}}/Admintheme/assets/js/vendors.min.js"></script>
	<script src="{{url('/')}}/Admintheme/assets/js/pages/chat-popup.js"></script>
	<script src="{{url('/')}}/Admintheme/assets/vendor_components/apexcharts-bundle/dist/apexcharts.min.js"></script>
    <script src="{{url('/')}}/Admintheme/assets/icons/feather-icons/feather.min.js"></script>

	<script src="{{url('/')}}/Admintheme/assets/vendor_components/OwlCarousel2/dist/owl.carousel.js"></script>
	<script src="../../../cdn.amcharts.com/lib/4/core.js"></script>
	<script src="../../../cdn.amcharts.com/lib/4/maps.js"></script>
	<script src="../../../cdn.amcharts.com/lib/4/geodata/worldLow.js"></script>
	<script src="../../../cdn.amcharts.com/lib/4/themes/kelly.js"></script>
	<script src="../../../cdn.amcharts.com/lib/4/themes/animated.js"></script>

	<!-- Riday Admin App -->
	<script src="{{url('/')}}/Admintheme/assets/js/template.js"></script>
	<script src="{{url('/')}}/Admintheme/assets/js/pages/dashboard.js"></script>


	<script src="{{url('/')}}/Admintheme/assets/js/pages/data-table.js"></script>





	<script src="{{url('/')}}/Admintheme/assets/vendor_components/datatable/datatables.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(".close").click(function(){
        $(".alert-block").css("display", "none");
      });
</script>

@php
    use Illuminate\Support\Facades\Auth;
    $url = Request::segment(2);
@endphp
<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar position-relative">
	  	<div class="multinav">
		  <div class="multinav-scroll" style="height: 100%;">
			  <!-- sidebar menu-->
			  <ul class="sidebar-menu" data-widget="tree">
				<li class="treeview">
				  <a href="#">
					<i class="icon-Home"></i>
					<span>Dashboard</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
					<li><a href="index.html"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Dashboard 1</a></li>
					<li><a href="index2.html"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Dashboard 2</a></li>
					<li><a href="index3.html"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Dashboard 3</a></li>
				  </ul>
				</li>
				<li class="treeview">
				  <a href="#">
					<i class="icon-Clipboard-check"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
					<span>Order</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
					<li><a href=""><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Order List</a></li>
					<li><a href=""><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Order Details</a></li>
				  </ul>
				</li>
				 <li class="treeview">
				  <a href="#">
					<i class="icon-Dinner"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span></i>
					<span>Delivery Man</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
					<li><a href="{{route('admin::add_menu') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Add New Delivery Man</a></li>
					<li><a href="{{ route('admin::view_menu') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Delivery Man List</a></li>
				  </ul>

				</li>
                <li class="treeview">
                    <a href="#">
                      <i class="icon-Dinner"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span></i>
                      <span>Menus</span>
                      <span class="pull-right-container">
                        <i class="fa fa-angle-right pull-right"></i>
                      </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="{{route('admin::add_menu') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Add New Menu</a></li>
                      <li><a href="{{ route('admin::view_menu') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Menu List</a></li>
                      <li><a href="{{ route('admin::view_category') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Categories</a></li>
                      <li><a href="{{ route('admin::view_addon') }}"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Addons</a></li>
                    </ul>

                  </li>
                  <li class="treeview">
                    <a href="#">
                      <i class="icon-Dinner"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span></i>
                      <span>Kitchen</span>
                      <span class="pull-right-container">
                        <i class="fa fa-angle-right pull-right"></i>
                      </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href=""><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Kitchen Details</a></li>


                    </ul>

                  </li>

			  </ul>


		  </div>
		</div>
    </section>
  </aside>

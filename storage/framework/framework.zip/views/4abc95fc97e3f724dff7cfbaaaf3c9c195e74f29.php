<?php $__env->startSection('content'); ?>
<style>
.font-text{
	font-size:33px;
	color:red;
}
.Chat-Main-Boxx {
    background: white;
    padding: 5px;
    border: 3px solid #dddddd4d;
}
.ChatProfile .ChatItem a {
    background: #f2f2f2;
    margin-bottom: 0px;
    width: 100%;
}
.ChatProfile {
    border-right: 3px solid #ddd;
}
.ChatHolder {
    background: #f2f2f2;
    padding:1px 3px;
    height: 522px;
    overflow: auto;
    border-bottom: 3px solid #f2f2f2;
}
.ChatHolder::-webkit-scrollbar {
  width: 4px;
}
.ChatHolder::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
.ChatHolder::-webkit-scrollbar-thumb {
  background:#ded2d2; 
  height: 10px;
}
.ChatHolder::-webkit-scrollbar-thumb:hover {
  background: #999; 
}

.ChatItem a .Images {
    width: 24%;
    text-align: center;
}
.ChatItem a .Images img {
	width: 70px;
    height: 70px;
    border-radius: 50px;
    background-size: cover;
    overflow: hidden;
    background-repeat: no-repeat;
}
.ChatItem a{
	width: 100%;
    display: inline-flex;
    padding: 5px;
    background: #fff;
    margin-bottom: 2px;
    transition: .5s;
}
.ChatItem a:hover{
  background:#f1f1f1;
}
.ChatItem a .Chat h3 {
    font-size: 17px;
    margin-top:9px;
    letter-spacing: .3px;
    color: #353131;
}
.ChatItem a .Chat p {
    font-size: 13px;
    color: #92959a;
}


.ChatProfileboxx .ChatItem a .Images {
    width: 12%;
}
/*.ChatProfile.ChatProfileboxx {
    border-left: 2px solid #ddd;
}*/
.Chat-View-Control {
    height: 450px;
    padding-right: 5px;
    overflow: auto;
}
.Chat-View-Control::-webkit-scrollbar {
  width: 6px;
}
.Chat-View-Control::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
.Chat-View-Control::-webkit-scrollbar-thumb {
  background:#ded2d2; 
  height: 10px;
}
.Chat-View-Control::-webkit-scrollbar-thumb:hover {
  background: #999; 
}



.containers {
  border:none;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding:5px 10px;
  margin: 10px 0;
}
.containers h3 {
    font-size: 17px;
    margin-top: 5px;
    color: #504a4a;
}
.containers p {
    font-size: 14px;
    color: #928c8c;
}
.darker {
  border-color:none;
  background-color:#cccccc85;
  text-align: right;
}

.containers::after {
  content: "";
  clear: both;
  display: table;
}

.containers img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
  height: 70px;
}

.containers img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}

.Chat-Input-Boxx form {
    display: flex;
}
.Chat-Input-Boxx {
    position: absolute;
    width: 99%;
    bottom: 0px;
    background: #f0f0f0;
    padding: 10px;
    left: 0px;
}
.Chat-Input-Boxx form .form-control {
    border: none;
    border-radius: 25px;
    padding-left: 25px;
    box-shadow: none;
    outline: none;
}
.Chat-Input-Boxx form button {
    position: absolute;
    background: transparent;
    border: none;
    top: 14px;
    right: 36px;
    font-size: 23px;
    color: #c3bdbd;
}
#Mob-Menu {
   display: none;
}  
.ChatItem a .Chat h3 .fa{
  display:none;
}

@media (min-width:200px) and (max-width: 575.98px){
   .Chat-View-Control {
      height:360px;
      padding-right: 5px;
      overflow: auto;
      margin-bottom: 65px;
    }
    #Mob-Menu {
        position: absolute;
        background: #fff;
        opacity: 1;
        z-index: 999;
        display: block;
    }
    #Desktop-Menus{
      display:none;
    }
    .ChatProfileboxx .ChatItem a .Images {
        width: 27%;
    }
    .ChatItem a .Chat h3 {
        font-size: 17px;
        margin-top: 0px;
        letter-spacing: .3px;
        color: #353131;
    }
    .ChatItem a .Chat h3 .fa {
        position: absolute;
        color: #0d758e;
        right: 18px;
        top: 14px;
        background: #f2f2f2;
        padding: 5px;
        font-size: 25px;
        display: block;
    }
    .ChatHolder {
        padding: 0px 0px;
    } 
    .ChatHolder {
        background: #f2f2f2;
        height: 369px;
        overflow: auto;
    }   
}
</style>
  <div class="text-center font-text">
  Admin Chat 
  </div>
  <div><a href="<?php echo e(route('admin::view_chat')); ?>" class="btn btn-primary" style="margin-left:80%;">Refresh</a></div>
<section class="my-3">
	<div class="container-fluid">
		<div class="Chat-Main-Boxx">
			<div class="row">
				<div class="col-md-4 pr-lg-0">
					<div id="Desktop-Menus">
						<div class="ChatProfile">
							<div class="ChatItem">
								<a href="<?php echo e(route('admin::view_chat')); ?>">
									<div class="Images">
										<img src="http://carlisting.api.aictsolution.com/storage/app/carlogo/carwaale_logo.png">
									</div>
									<div class="Chat">
										<h3>Admin </h3>
										<p>Admin Of that Website</p>
									</div>
								</a>
							</div>
						</div>
						<div class="ChatHolder">
							<?php
								if(sizeof($data['userList'])>=1){
									foreach($data['userList'] as $key => $value){
										?>				
											<div class="ChatItem">
												<a href="<?php echo e(route('admin::view_chat',['id' => $value->id])); ?>">
													<div class="Images">
														<img src="<?php echo $value->authorise_persons_photo;?>" style="height:70px;width:70px;border-radius:50px;position:inline;">
													</div>
													<div class="Chat" style="padding-left:50px;width:100%!important;" >
														<h3><?php echo $value->authorized_person_name;?></h3>
														<p><?php echo $value->email_id;?></p>
													</div>
												</a>
											</div>
										<?php
									}
								}
							?>
						</div>
					</div>
				</div>
				<?php
					//dd($data['currentUser']);
					foreach($data['userList'] as $key => $value){
						if($data['currentUser']==0){
							$curentUserId=$value->id;
							$currentUserName=$value->authorized_person_name;
							$currentUserEmail=$value->email_id;
							$currentUserPhoto=$value->authorise_persons_photo;
							break;
						}
						else if($value->id==$data['currentUser']){
							$curentUserId=$value->id;
							$currentUserName=$value->authorized_person_name;
							$currentUserEmail=$value->email_id;
							$currentUserPhoto=$value->authorise_persons_photo;
							break;
						}
					}	
				?>
				<div class="col-md-8 pl-lg-0">
					<div class="Chat-Input-Main-Box">
						<div class="ChatProfile ChatProfileboxx">
							<div class="ChatItem">
								<a href="<?php echo e(route('admin::view_chat',['id' => $curentUserId])); ?>">
									<div class="Images">
										<img src="<?php echo $currentUserPhoto;?>">
									</div>
									<div class="Chat">
										<h3><?php echo $currentUserName;?></h3>
										<p><?php echo $currentUserEmail?></p>
									</div>
								</a>
							</div>
						</div>
						<?php
							//dd($data['chatHistory']);
						?>
						<div class="ChatBoxx">
							<div class="Chat-View-Control pl-lg-2">

								<?php
									$adminId=1;
									foreach($data['chatHistory'] as $key => $value){
										if(($value->sender==$curentUserId or  $value->receiver==$curentUserId)){
								?>
										<div class="containers <?php if($value->sendertype=='user'){ echo 'darker';}?>">
											<img src="	
													<?php
														if($value->sendertype=='user')
														{
															echo $currentUserPhoto;
														}
														else{
															$image='http://carlisting.api.aictsolution.com/storage/app/carlogo/carwaale_logo.png';
															echo $image; //Admin Photo Path Mandatory
														}
													?>
													" alt="Chat User" class="<?php if($value->sendertype=='user'){ echo 'right';}?>" style="width:100%;">
											<h3>
												<?php
													if($value->sendertype=='user')
													{
														echo $currentUserName;
													}
													else{
														echo 'Admin';
													}
												?>
											</h3>
											<p><?php echo $value->sms;?></p>
											<span class="<?php if($value->sendertype=='user'){ echo 'time-right';}else{ echo 'time-left';}?>"><?php echo date('h:i a', strtotime($value->created_at));?></span>
										</div>
								<?php
										}
									}
								?>								
							</div>
								
							<div class="Chat-Input-Boxx">
								<form action="<?php echo e(route('admin::show_chat')); ?>" method="get">
								<input type="hidden" value="<?php echo $curentUserId; ?>" name="receiverid">
									<input type="text" class="form-control" placeholder="Type a message" name="message">
									<button type="submit"><i class="fa fa-paper-plane"></i></button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
</section>
<?php $__env->startPush('scripts'); ?>
<script>
	function openNav() {
	  document.getElementById("Mob-Menu").style.width = "250px";
	  document.getElementById("closeBtn").style.display = "block";
	}

	function closeNav() {
	  document.getElementById("Mob-Menu").style.width = "0";
	  document.getElementById("closeBtn").style.display = "none";
	}
</script>
	
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.layout.adminlayout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/chat/view.blade.php ENDPATH**/ ?>
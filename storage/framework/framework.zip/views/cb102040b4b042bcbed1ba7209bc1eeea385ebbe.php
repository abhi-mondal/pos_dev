
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo e(url('/')); ?>/frontend/js/core.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/frontend/js/script.js"></script><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/elements/footerjs.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!--<p>.....</p>-->
     <div style="height:350px;width:200px;background-color:yellow;">
        <br>
         <h2 style="text-align:center;margin-top:20px;">CARWAALE</h2>
       <h3 style="text-align:center;">Account Varification</h3>
         <p style="text-align:center;font-size:20px;padding:20px;">Your Account hasbeen Approve By CarwalleApp Admin</p>
    </div>
</body>
</html><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/veryfy_mail.blade.php ENDPATH**/ ?>
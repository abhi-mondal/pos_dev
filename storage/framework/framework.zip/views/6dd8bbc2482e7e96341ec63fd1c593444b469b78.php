<?php $__env->startSection('title', 'Add New User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Translater Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">Translater</li>
                            <li class="breadcrumb-item active">Add New Translater</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Add Translater</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form role="form" action="<?php echo e(route('admin::save_person')); ?>" enctype="multipart/form-data" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
                                            <label>Enter Full Name</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('email')? 'has-error':''); ?>">
                                            <label>Enter Email ID</label>
                                            <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('phone')? 'has-error':''); ?>">
                                            <label>Enter Phone Number</label>
                                            <input type="number" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('password')? 'has-error':''); ?>">
                                            <label>Enter Password</label>
                                            <input type="text" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('gender')? 'has-error':''); ?>">
                                            <label>Gender</label>
                                            <select name="gender" class="form-control" value="<?php echo e(old('gender')); ?>">
                                        <option>Male</option>
                                        <option>FeMale</option>  
                                        <option>Oth</option>  
                                        </select>
                                            <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('state')? 'has-error':''); ?>">
                                            <label>State</label>
                                            <input type="text" name="state" class="form-control" value="<?php echo e(old('email')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('city')? 'has-error':''); ?>">
                                            <label>City</label>
                                            <input type="text" name="city" class="form-control" value="<?php echo e(old('phone')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('zip')? 'has-error':''); ?>">
                                            <label>Zip Code</label>
                                            <input type="number" name="zip" class="form-control" value="<?php echo e(old('password')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('zip')); ?></span>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('charge')? 'has-error':''); ?>">
                                            <label>Charge</label>
                                            <input type="number" name="charge" class="form-control" value="<?php echo e(old('phone')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('charge')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('astatus')? 'has-error':''); ?>">
                                            <label>Available Status</label>
                                            <select name="astatus" class="form-control" value="<?php echo e(old('name')); ?>">
                                        <option value="1">Available</option>
                                        <option value="0">Un Available</option>  
                                       
                                        </select>
                                            <span class="text-danger"><?php echo e($errors->first('astatus')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group <?php echo e($errors->has('img')? 'has-error':''); ?>">
                                            <label>Image</label>
                                            <input type="file" name="img" class="form-control" value="<?php echo e(old('password')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('img')); ?></span>
                                        </div>
                                    </div>
</div>

                                    
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Add Translater</button>
                                    <a href="<?php echo e(route('admin::view_user')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Admin/pages/person/add.blade.php ENDPATH**/ ?>
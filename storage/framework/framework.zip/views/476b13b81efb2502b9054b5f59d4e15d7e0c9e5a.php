<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Messages Dropdown Menu -->
  
    <!-- Notifications Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-bell"></i>
                <span class="badge badge-warning navbar-badge"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-item dropdown-header">Profile Setting</span>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('admin::editProfile',['id' => Auth::user()->id])); ?>" class="dropdown-item">
                    <i class="fas fa-envelope mr-2"></i> Update Profile
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('admin::chnagepassword')); ?>" class="dropdown-item">
                    <i class="fas fa-users mr-2"></i> Change Password
                </a>
                <div class="dropdown-divider"></div>
            </div>
        </li>
        <!--<li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
            </a>
        </li>-->
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('logout')); ?>">
                Log Out <i class="fas fa-sign-out-alt"></i>
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\translater\resources\views/Admin/elements/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Add New User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Car Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">All car</li>
                            <li class="breadcrumb-item active">Add New car</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Add Car</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form role="form" style="height:400px; overflow:scroll;" action="<?php echo e(route('admin::save_allcar')); ?>" method="post" enctype="multipart/form-data" multi>
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <div class="col-sm-12">
                                       
                                        <div class="form-group <?php echo e($errors->has('manufacturer_company')? 'has-error':''); ?>">
                                            <label>Manufacturer Company</label>
                                            <select class="form-control" name="manufacturer_company">
                                                <option value="mahindra">Mahindra</option>
                                                <option value="opel">Opel</option>
                                                <option value="tata">Tata</option>
                                                <option value="volkswagen">Volkswagen</option>
                                                <option value="honda">Honda</option>
                                                <option value="renault">Renault</option>
                                                <option value="bmw">Bmw</option>
                                                <option value="jeep">Jeep</option>
                                                <option value="ford">Ford</option>
                                                <option value="nissan">Nissan</option>
                                                <option value="audi">Audi</option>
                                                <option value="datsun">Datsun</option>
                                                <option value="tesla">Tesla</option>
                                                
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('manufacturer_company')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('model')? 'has-error':''); ?>">
                                            <label >Model Number</label>
                                            <input class="form-control" name="model" placeholder="Enter Model Number!!">
                                                
                                            <span class="text-danger"><?php echo e($errors->first('model')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('fuel_type')? 'has-error':''); ?>">
                                            <label >Fuel Type</label>
                                            <select class="form-control" name="fuel_type">
                                            <option>Petrol</option>
                                            <option>Petrol+CNG</option>
                                            <option>Diesel</option>
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('fuel_type')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('registration_date')? 'has-error':''); ?>">
                                            <label>Registration Date</label>
                                            <input type="text" name="registration_date" class="form-control" value="<?php echo e(old('registration_date')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('registration_date')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('km_driven')? 'has-error':''); ?>">
                                            <label>km_driven</label>
                                            <input type="text" name="km_driven" class="form-control" value="<?php echo e(old('km_driven')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('km_driven')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('insurance_type')? 'has-error':''); ?>">
                                            <label>insurance_type</label>
                                            <select class="form-control" name="insurance_type">
                                            <option>Frist</option>
                                            <option>Second</option>
                                            <option>Third</option>
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('insurance_type')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('damaged')? 'has-error':''); ?>">
                                            <label>damaged</label>
                                            <select class="form-control" name="damaged">
                                            <option>Yes</option>
                                            <option>No</option>
                                            
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('damaged')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('accidental')? 'has-error':''); ?>">
                                            <label>accidental</label>
                                            <select class="form-control" name="accidental">
                                            <option>Yes</option>
                                            <option>No</option>
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('accidental')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('rc_availability')? 'has-error':''); ?>">
                                            <label>rc_availability</label>
                                            <select class="form-control" name="rc_availability">
                                            <option>Yes</option>
                                            <option>No</option>
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('rc_availability')); ?></span>
                                        </div>
                                        
                                        <div class="form-group <?php echo e($errors->has('rto_noc_issued')? 'has-error':''); ?>">
                                            <label>rto_noc_issued</label>
                                            <select class="form-control" name="rto_noc_issued">
                                            <option>Yes</option>
                                            <option>No</option>
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('rto_noc_issued')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('fitness_up_to')? 'has-error':''); ?>">
                                            <label>fitness_up_to</label>
                                            <select class="form-control" name="fitness_up_to">
                                            <option>1 Year</option>
                                            <option>2 year</option>
                                            <option>3 year</option>
                                            <option>4 year</option>
                                            <option>5 year</option>
                                            <option>6 year</option>
                                            <option>7 year</option>
                                            <option>8 year</option>
                                            <option>9 year</option>
                                            <option>10 year</option>
                                            <option>11 year</option>
                                            <option>12 year</option>
                                            <option>13 year</option>
                                            <option>14 year</option>
                                            <option>15 year</option>
                                            <select>
                                            
                                            <span class="text-danger"><?php echo e($errors->first('fitness_up_to')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('road_tax_paid')? 'has-error':''); ?>">
                                            <label>road_tax_paid</label>
                                            <select class="form-control" name="road_tax_paid">
                                            <option>Yes</option>
                                            <option>No</option>
                                            
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('road_tax_paid')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('rto_city')? 'has-error':''); ?>">
                                            <label>rto_city</label>
                                            <select class="form-control" name="rto_city">
                                            <option>Delhi</option>
                                            <option>Noida</option>
                                            <option>Durgapur</option>
                                            <option>Kolkata</option>
                                            
                                            </select>
                                            <span class="text-danger"><?php echo e($errors->first('rto_city')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('chassis_no')? 'has-error':''); ?>">
                                            <label>chassis_no</label>
                                            <input type="text" name="chassis_no" class="form-control" value="<?php echo e(old('chassis_no')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('chassis_no')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('price')? 'has-error':''); ?>">
                                            <label>price</label>
                                            <input type="text" name="price" class="form-control" value="<?php echo e(old('price')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('email')? 'has-error':''); ?>">
                                            <label>Car'S Image</label>
                                            <input type="file" name="file[]" multiple class="form-control" >
                                            <span class="text-danger"><?php echo e($errors->first('file')); ?></span>
                                        </div>
                                    </div>
                                   
                                    
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Add car</button>
                                    <a href="<?php echo e(route('admin::view_allcar')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/allcar/add.blade.php ENDPATH**/ ?>
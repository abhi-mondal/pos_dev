<?php $__env->startSection('title', 'Update User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Help Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">Help Center</li>
                            <li class="breadcrumb-item active">Update Help Center</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Update Help center</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start --> 
                            <form role="form" action="<?php echo e(route('admin::update_help')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <div class="card-body">
                                    <div class="col-sm-12">
                                        
                                        <div class="form-group <?php echo e($errors->has('guide')? 'has-error':''); ?>">
                                            <label>Mobile Number</label>
                                            <input type="number" class="form-control"  name="number" value="<?php echo e($details->mobilenumber); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('guide')? 'has-error':''); ?>">
                                            <label>Email Id</label>
                                            <input type="email" class="form-control"  name="emailid" value="<?php echo e($details->emailid); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('guide')? 'has-error':''); ?>">
                                            <label>facebook Id</label>
                                            <input type="text" class="form-control"  name="facebook" value="<?php echo e($details->facebookid); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('guide')? 'has-error':''); ?>">
                                            <label>Instagram Id</label>
                                            <input type="text" class="form-control"  name="instagamid" value="<?php echo e($details->instagramid); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('')); ?></span>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('guide')? 'has-error':''); ?>">
                                            <label>Twiter Id</label>
                                            <input type="text" class="form-control"  name="twiterid" value="<?php echo e($details->twiterid); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('')); ?></span>
                                        </div>
                                       
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Update Help</button>
                                    <a href="<?php echo e(route('admin::view_help')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    <div class="content-wrapper">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/help/edit.blade.php ENDPATH**/ ?>
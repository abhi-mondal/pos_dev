<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>

<section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(<?php echo e(url('/')); ?>/frontend/images/breadcrumbs-image-1.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">About Us</h6>
              <h1 class="heading-decorate heading-decorate-lg breadcrumbs-custom-title"><span class="heading-decorate-symbol font-weight-ubold">A</span><span class="heading-decorate-main">About Us</span></h1>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="active">About Us</li>
            </ul>
          </div>
        </div>
      </section>
      <!-- Overview-->
      <section class="section section-lg bg-gray-100">
        <div class="container">
          <div class="row row-50 justify-content-center justify-content-lg-between">
            <div class="col-md-10 col-lg-6">
              <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">o</span><span class="heading-decorate-main">overview</span></h3>
              <h4 class="offset-top-3">Verbonix is the leading provider of translation and educational services delivering results since 1999.</h4>
              <p>Valebats sunt racanas de clemens rumor. Est nobilis historia, cesaris. Nunquam carpseris historia. Ubi est fidelis rumor? Domesticus apolloniatess ducunt ad usus. Barcass mori, tanquam magnum ionicis tormento. Cum calceus accelerare, omnes guttuses desiderium fidelis, alter castores.</p>
              <div class="group group-middle"><a class="button button-sm-big button-primary button-winona" href="services.html">View Our services</a><a class="button button-sm-big button-primary-outline button-winona" href="careers.html">join our team</a></div>
            </div>
            <div class="col-md-10 col-lg-6">
              <div class="block-retro">
                <div class="block-retro-overlay"></div>
                <div class="block-retro-image"><img class="img-responsive" src="<?php echo e(url('/')); ?>/frontend/images/ab1.jpg" alt="" width="570" height="368"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Who We Are-->
      <section class="section section-lg section-last text-center">
        <div class="container">
          <h3 class="heading-decorate text-center"><span class="heading-decorate-symbol font-weight-ubold">W</span><span class="heading-decorate-main">Who We Are</span></h3>
          <div class="row row-50">
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab2.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Jean Thompson</h4>
                  <p class="profile-minimal-position">Chief Technology Officer</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab3.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Brian Payne</h4>
                  <p class="profile-minimal-position">Leading Translator</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab4.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Nathan Porter</h4>
                  <p class="profile-minimal-position">CEO, Founder</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab5.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Marie Fernandez</h4>
                  <p class="profile-minimal-position">Interpreter</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab6.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Sam Williams</h4>
                  <p class="profile-minimal-position">English Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="<?php echo e(url('/')); ?>/frontend/images/ab7.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Bruce Wilson</h4>
                  <p class="profile-minimal-position">German Teacher</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-md text-center bg-gray-100">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-sm-10 col-md-12">
              <div class="box-cta-thin">
                <h3 class="wow-outer"><span class="wow slideInRight"><span class="font-weight-light">Professional</span> Translation solutions</span></h3>
                <div class="wow-outer button-outer"><a class="button button-secondary button-winona wow slideInLeft" href="services.html">order TRANSLATION</a></div>
              </div>
            </div>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/about.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>
<style>
      body{
        background-color: #eee;
      }
      #text1{
        color: black;
    padding-top: 52PX;
    font-weight: 500;
    margin-left: 19px;
    }
    .form-control{
      width: 274px;
    }
    .fas{
      color: #2b3cb9;
    }

    .far{
      color: #2b3cb9;
    }
    .box{
      margin-top: 40px;
    }
.btn{
  background: black;
    border: black;
    margin-top: 11px;
    color: white;
    height: 38px;
    font-size: 14px;
}

    </style>
<div class="page">
      <!-- Page Header-->
      
      <!-- Breadcrumbs -->
      <section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(<?php echo e(url('/')); ?>/frontend/images/breadcrumbs-image-1.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Services</h6>
              <h1 class="heading-decorate heading-decorate-lg breadcrumbs-custom-title"><span class="heading-decorate-symbol font-weight-ubold">S</span><span class="heading-decorate-main">Our<br>translatter services</span></h1>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.php">Home</a></li>
              <li><a href="services.php">Services</a></li>
              
            </ul>
          </div>
        </div>
      </section>
     

        <div class="container">
          <div class="row" style="background-color: #eee;">
            <div class="col-lg-4 col-md-4 col-sm-4" style="margin-top: 30px;">
            <form action="#" method="post">
            <!-- <h1 id="text1">Translate from</h1> -->
            <select data-placeholder="Begin typing a name to filter..." name="test" class="form-control">
                         <option value="2">Laguage</option>
                         <option value="2">Chinese (Simplified)</option>
                         <option value="3">Chinese (Traditional)</option>
                         <option value="4">Danish</option>
                         <option value="5">Dutch</option>
                         <option value="6">English</option>
                         <option value="7">French</option>
                         <option value="8">French (canada)</option>
                         <option value="9">German</option>
                         <option value="10">Indonasian</option>
                         <option value="11">Italian</option>
                         <option value="12">Japanes</option>
                         <option value="13">korean</option>
                         <option value="14">Malay</option>
                         <option value="15">Norwegian</option>
                         <option value="16">polish</option>
                         <option value="17">Portuguese (Brazil)</option>
                         <option value="18">Portuguese (Europe)</option>
                         <option value="19">Russian</option>
                         <option value="20">Spanish (Latin America</option>
                         <option value="21">Spanish (Spain)</option>
                         <option value="22">Swedish</option>
                         <option value="23">Thai</option>
                     </select>
 
                    </form>
                    <div class="cheakbox">
                    <h4 style="font-weight: bold; margin-top: 30px">Filter Condition</h4><br>
                                      <form action="javascript:void(0);">
                    <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                    <label for="vehicle1"> New</label><br><br>
                    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                    <label for="vehicle2"> Experienced</label><br>
                   
                    </form>
                    </div>
                    <!-- <div class="review">
                      <h4 style="font-weight: bold; margin-top: 30px">Avg. Customer Review</h4>
                      <div class="rate" style="margin-top: 30px;">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      </div>
                      <div class="rate" style="margin-top: 10px;">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      </div>

                      <div class="rate" style="margin-top: 10px;">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      </div>

                      <div class="rate" style="margin-top: 10px;">
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      </div>
                    </div> -->

                    <div class="price">
                    <h4 style="font-weight: bold; margin-top: 30px">price</h4><br>
                    <form action="javascript:void(0);">
                    <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                    <label for="vehicle1"> UNDER $25</label><br><br>
                    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                    <label for="vehicle2"> $25 TO $50</label><br><br>

                    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                    <label for="vehicle2"> $50 TO $100</label><br><br>

                    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                    <label for="vehicle2"> $100 TO $200</label><br>


                   
                    </form>
                    </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-4">



              <div class="row">

              <?php if(!empty($translaters)): ?>
              <?php $__currentLoopData = $translaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-4 box">
                  <div class="img-box">
                    <img src="<?php echo e($translater->image); ?>" style="width: 235px; height: 240px">
                  </div>
                  <div class="img-content">
                    <center>
                    <p style="font-weight: bold; color: black"><?php echo e($translater->full_name); ?></p>
                    <p style="font-weight: bold; color: black">$ <?php echo e($translater->charge); ?></p>
                    <div class="rate" style="margin-top: 10px;">
                       <?php if($translater->is_available==1): ?>
                        <p style="background-color: aqua;padding: 10;font-weight: 600;border-radius: 44px;width: fit-content;">Available</p>
<?php else: ?>
<p>Un Available</p>
<?php endif; ?>
                      </p>
                      </div>
                      <button type="button" class="btn">View Details</button>
                    </center>
                  </div>
                </div>
                
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
              </div>

            
              


            </div>
          </div>
        </div>
      
      <!-- Testimonials-->
      
      <section class="section section-md bg-primary-darker text-center">
        <div class="container">
          <div class="box-cta-1">
            <h3><span class="font-weight-light">We Offer Quality</span> Translation Services</h3><a class="button button-lg button-secondary button-winona" href="#">Free consultation</a>
          </div>
        </div>
      </section>

      <!-- Page Footer-->
     
    
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    
<?php $__env->stopSection(); ?>
<script>
  <script>
                $(".chosen-select").chosen({
  no_results_text: "Oops, nothing found!"
})
              </script>
  </script>
<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/translators.blade.php ENDPATH**/ ?>
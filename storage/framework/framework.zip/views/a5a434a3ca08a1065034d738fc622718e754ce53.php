<footer class="main-footer">
    <strong>Copyright &copy; 2021 .</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
       
    </div>
</footer>
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
<!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
<?php /**PATH C:\xampp\htdocs\translater\resources\views/Admin/elements/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Add New User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Logo Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">Logo</li>
                            <li class="breadcrumb-item active">Add New Logo</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Add Logo</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form role="form" style="height:400px; overflow:scroll;" action="<?php echo e(route('admin::save_alllogo')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <div class="col-sm-12">                                       

                                        <div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
                                            <label>Name</label>
                                            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('image')? 'has-error':''); ?>">
                                            <label>Upload logo</label>
                                            <input type="file" name="image" class="form-control" required>
                                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                        </div>
                                    </div>                                   
                                    
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Add logo</button>
                                    <a href="<?php echo e(route('admin::view_alllogo')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/logo/add.blade.php ENDPATH**/ ?>
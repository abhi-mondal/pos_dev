<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>All Repoart List</h1>
                    </div>
                   
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Repoart Problems</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <?php if(Session::has('flash_message_error')): ?>
                                    <div class="alert alert-error alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong><?php echo session('flash_message_error'); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('flash_message_success')): ?>
                                    <div class="alert alert-success alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong><?php echo session('flash_message_success'); ?></strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-header">
                              
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Name</th>
                                        <th>Problem</th>                                      
                                       <th>action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($getuser)): ?>
                                        <?php $i=0; ?>
                                        <?php $__currentLoopData = $getuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++; ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($data->username); ?></td>
                                                <td><?php echo e($data->problem); ?></td>
                                                  
                                                                                                                   
                                                <?php /*<td><img src="C:/xampp/htdocs/demoadmin/storage/app/{{$data->image}}"></td> */ ?>
                                                <td>
                                                    
                                                    <!-- <a href="#modal-sm" data-toggle="modal" data-target="#modal-sm" class="btn btn-danger" role="button" onclick="getdelRoute('<?php echo e(route('admin::del_allrepoart',['id' => $data->id])); ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a> -->
                                                    <a href="#modal-sm" data-toggle="modal" data-target="#modal-sm" class="btn btn-danger" role="button" onclick="getdelRoute('<?php echo e(route('admin::del_allrepoart',['id' => $data->id])); ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                    <th>Sl No</th>
                                        <th>Name</th>
                                        <th>Problem</th>
                                      
                                       <th>action</th> 
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>

    <div class="modal fade" id="modal-sm">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Please Select Button</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are You Delete This Record! ?</p>
                </div>
                <div class="modal-footer justify-content-between">
                    <a href="" class="btn btn-default" data-dismiss="modal">No</a>
                    <a href="" id="delroute" class="btn btn-primary">Yes</a>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- <?php $__env->startPush('scripts'); ?>
        <script>
            var Inactive='Inactive';
            var Active='Active';
            function status(id,status) {
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route('admin::user_status')); ?>',
                    data: {
                        _token: '<?php echo csrf_token();?>',
                        id: id,
                        status: status
                    },
                    success: function (data) {
                        var resp = JSON.parse(data);
                        $('#status' + resp.id).html(resp.html);
                        $(document).find('.child #status'+resp.id).html(resp.html);
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoadmin\resources\views/Admin/pages/allrepoart/viewwwww.blade.php ENDPATH**/ ?>
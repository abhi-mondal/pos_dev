<?php $__env->startSection('title', 'Add New User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>User Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">User</li>
                            <li class="breadcrumb-item active">Add New User</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Add User</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form role="form" action="<?php echo e(route('admin::save_user')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
                                            <label>Enter Your Full Name</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('email')? 'has-error':''); ?>">
                                            <label>Enter Your Email ID</label>
                                            <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('phone')? 'has-error':''); ?>">
                                            <label>Enter Your Phone Number</label>
                                            <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('password')? 'has-error':''); ?>">
                                            <label>Enter Your Password</label>
                                            <input type="text" name="password" class="form-control" value="<?php echo e(old('password')); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Add User</button>
                                    <a href="<?php echo e(route('admin::view_user')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoadmin\demoadmin\resources\views/Admin/pages/users/add.blade.php ENDPATH**/ ?>
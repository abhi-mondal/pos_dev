<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-warning" style="height:143px;">
                            <div class="inner">
                                
                                <h3>30</h3>
                                <p style="font-size:20px;">User Registrations</p>
                            </div>
                           
                            
                        </div>
                    </div>
                     <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info" style="height:143px;">
                            <div class="inner">
                                
                                <h3>50</h3>
                                <p style="font-size:20px;">Total Posted Car</p>
                            </div>
                           
                            
                        </div>
                    </div>
                     <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success" style="height:143px;">
                            <div class="inner">
                               
                                <h3>60</h3>
                                <p style="font-size:20px;">Total Payments</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-inr"></i>
                            </div>
                            
                        </div>
                    </div>
                    <!-- ./col -->
                    
                    <!-- ./col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Admin/dashboard/dashboard.blade.php ENDPATH**/ ?>
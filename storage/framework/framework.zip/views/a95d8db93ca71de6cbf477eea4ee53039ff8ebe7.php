<?php $__env->startSection('title', 'Update User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Guideline Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">All Guideline </li>
                            
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Update Guideline</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start --> 
                            <form role="form" action="<?php echo e(route('admin::update_allguide')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <div class="card-body">
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('Enter Guideline text')? 'has-error':''); ?>">
                                            <label>Guideline</label>
                                            <textarea style="height:250px;" type="text" name="manufacturer_company" class="form-control"><?php echo e($details->guideline); ?></textarea>
                                            <span class="text-danger"><?php echo e($errors->first('Enter Guideline text')); ?></span>
                                        </div>
                                       
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Update Guideline</button>
                                    <a href="<?php echo e(route('admin::view_allguide')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    <div class="content-wrapper">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/guideline/edit.blade.php ENDPATH**/ ?>
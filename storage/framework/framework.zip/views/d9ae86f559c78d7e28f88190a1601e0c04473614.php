<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>
<div class="swiper-container swiper-slider swiper-slider-minimal" data-loop="true" data-autoplay="3500" data-simulate-touch="false">
          <div class="swiper-wrapper">
            <div class="swiper-slide" data-slide-bg="<?php echo e(url('/')); ?>/frontend/images/slider-minimal-slide-1-1920x888.jpg">
              <div class="swiper-slide-caption">
                <div class="container">
                  <div class="row">
                    <div class="col-md-10 col-xl-7">
                      <div class="heading-decorate-wrap">
                        <h1 class="heading-decorate text-large"><span class="heading-decorate-symbol font-weight-ubold">O</span><span class="heading-decorate-main"><span class="font-weight-ubold">Professional Translation</span> <span class="font-weight-light">Solutions</span></span></h1><a class="button button-secondary button-winona" href="" data-wow-delay=".4s">Learn more</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide" data-slide-bg="<?php echo e(url('/')); ?>/frontend/images/slider-minimal-slide-2-1920x888.jpg">
              <div class="swiper-slide-caption">
                <div class="container">
                  <div class="row">
                    <div class="col-md-10 col-xl-7">
                      <div class="heading-decorate-wrap">
                        <h1 class="heading-decorate text-large"><span class="heading-decorate-symbol font-weight-ubold">W</span><span class="heading-decorate-main"><span class="font-weight-ubold">high-Quality Educational</span> <span class="font-weight-light">services</span></span></h1><a class="button button-secondary button-winona" href="" data-wow-delay=".4s">Learn more</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide" data-slide-bg="<?php echo e(url('/')); ?>/frontend/images/slider-minimal-slide-3-1920x888.jpg">
              <div class="swiper-slide-caption">
                <div class="container">
                  <div class="row">
                    <div class="col-md-10 col-xl-7">
                      <div class="heading-decorate-wrap">
                        <h1 class="heading-decorate text-large"><span class="heading-decorate-symbol font-weight-ubold">O</span><span class="heading-decorate-main"><span class="font-weight-ubold">Combining Translation</span> <span class="font-weight-light">and education</span></span></h1><a class="button button-secondary button-winona" href="" data-wow-delay=".4s">Learn more</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination swiper-pagination-custom"></div>
        </div>
      </section>
      <section class="section section-lg">
        <div class="container">
          <div class="row row-50 justify-content-center justify-content-lg-between flex-lg-row-reverse align-items-center">
            <div class="col-md-10 col-lg-6 col-xxl-5">
              <div class="heading-decorate-wrap">
                <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">A</span><span class="heading-decorate-main">A Few Words About Us</span></h3>
                <p class="wow-outer"><span class="wow slideInDown" data-wow-delay=".05s">Verbonix is a global translation services and language courses company founded in 1999. We aim to deliver quliaty translation and educational services for everyone.</span></p>
                <p class="wow-outer"><span class="wow slideInDown" data-wow-delay=".1s">With a core group of more than 700 professional linguists and tutors operating from six continents, we serve the needs of our clients worldwide. Whatever your language needs are, we are here to help.</span></p>
                <div class="wow-outer button-outer"><a class="button button button-primary button-winona wow slideInDown" data-wow-delay=".1s" href="">Read More</a></div>
              </div>
            </div>
            <div class="col-md-10 col-lg-6">
              <div class="block-modern">
                <div class="block-modern-overlay"></div>
                <div class="block-modern-image"><img class="img-responsive wow slideInLeft" src="<?php echo e(url('/')); ?>/frontend/images/large-features-3-570x368.jpg" alt="" width="570" height="368"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Pricing-->
      <section class="section section-lg text-center bg-primary-gradient">
        <div class="container">
          <div class="heading-decorate-wrap text-center">
            <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">W</span><span class="heading-decorate-main">What we offer</span></h3>
            <p class="wow-outer"><span class="text-width-1 wow slideInDown">In this section, you can learn more about the services Verbonix offers to its clients. We are always ready to provide you with quality translation, interpreting, and educational services.</span></p>
          </div>
          <div class="table-info-group wow-outer">
            <article class="table-info">
              <div class="table-info-icon"><span class="icon mdi mdi-file-document"></span></div>
              <h5 class="table-info-title"><a href="">Translation Services</a></h5>
              <ul class="table-info-list">
                <li>Advertising translation</li>
                <li>Banking and finance translation</li>
                <li>GDPR and legal translation</li>
                <li>Software and technology translation</li>
              </ul><a class="button button-sm button-default button-winona" href="">Order</a>
            </article>
            <article class="table-info">
              <div class="table-info-icon"><span class="icon mdi mdi-briefcase-check"></span></div>
              <h5 class="table-info-title"><a href="">interpreting services</a></h5>
              <ul class="table-info-list">
                <li>On-site interpreting</li>
                <li>Business and conference interpreting</li>
                <li>Sight and telephone translation</li>
                <li>Video and audio translation</li>
              </ul><a class="button button-sm button-default button-winona" href="">Order</a>
            </article>
            <article class="table-info">
              <div class="table-info-icon"><span class="icon mdi mdi-map"></span></div>
              <h5 class="table-info-title"><a href="">content services</a></h5>
              <ul class="table-info-list">
                <li>Transcription</li>
                <li>Proofreading and quality assessment</li>
                <li>Content summarization and categorization</li>
                <li>Ads review and sentiment analysis</li>
              </ul><a class="button button-sm button-default button-winona" href="">Order</a>
            </article>
            <article class="table-info">
              <div class="table-info-icon"><span class="icon mdi mdi-web"></span></div>
              <h5 class="table-info-title"><a href="">Educational<br class="d-none d-lg-block"> services</a></h5>
              <ul class="table-info-list">
                <li>English for business</li>
                <li>Foreign languages for beginners</li>
                <li>German for kids and teenagers</li>
                <li>Grammar and punctuation course</li>
              </ul><a class="button button-sm button-default button-winona" href="">Order</a>
            </article>
          </div>
        </div>
      </section>
      <section class="section section-xl section-indie">
        <div class="container">
          <div class="row row-50 section-indie-row justify-content-center justify-content-lg-end">
            <div class="col-md-10 col-lg-1 section-indie-col">
              <div class="section-indie-image"><img src="<?php echo e(url('/')); ?>/frontend/images/image-aside-01-1143x584.png" alt="" width="1143" height="584"/>
              </div>
            </div>
            <div class="col-md-10 col-lg-6 col-xl-5">
              <h5 class="text-uppercase font-weight-light">quality Translation & language teaching</h5>
              <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">G</span><span class="heading-decorate-main">Great Industry Expertise</span></h3>
              <p class="wow-outer"><span class="wow slideInDown" data-wow-delay=".05s">With over 20 years of professional experience in translation, interpreting, and education, we utilize a rigorously tested network of industry experts to ensure the best results.</span></p>
              <div class="wow-outer button-outer"><a class="button button-sm button-primary button-winona wow slideInDown" data-wow-delay=".1s" href="services.html">Browse our services</a></div>
            </div>
          </div>
        </div>
      </section>
      <section class="section bg-primary-gradient">
        <div class="range justify-content-xl-between">
          <div class="cell-lg-6 cell-xl-5 align-self-center container">
            <div class="row">
              <div class="col-md-10 cell-inner">
                <div class="section-lg inset-right-2">
                  <div class="heading-decorate-wrap">
                    <div class="heading-decorate-img"><img src="<?php echo e(url('/')); ?>/frontend/images/section-decor-721x382.png" alt="" width="721" height="382"/>
                    </div>
                    <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">E</span><span class="heading-decorate-main">Experts in 20 Languages</span></h3>
                    <p class="wow fadeIn">Verbonix works with over 20 various languages, from English to Portuguese. We are the world’s trusted provider of quality translation and educational solutions as well as onsite interpreting, and document translation services.</p>
                    <div class="progress-linear-outer wow-outer">
                      <!-- Linear progress bar-->
                      <article class="progress-linear">
                        <div class="progress-header">
                          <p>English</p><span class="progress-value">90</span>
                        </div>
                        <div class="progress-bar-linear-wrap">
                          <div class="progress-bar-linear"></div>
                        </div>
                      </article>
                    </div>
                    <div class="progress-linear-outer wow-outer">
                      <!-- Linear progress bar-->
                      <article class="progress-linear">
                        <div class="progress-header">
                          <p>German</p><span class="progress-value">65</span>
                        </div>
                        <div class="progress-bar-linear-wrap">
                          <div class="progress-bar-linear"></div>
                        </div>
                      </article>
                    </div>
                    <div class="progress-linear-outer wow-outer">
                      <!-- Linear progress bar-->
                      <article class="progress-linear">
                        <div class="progress-header">
                          <p>French</p><span class="progress-value">100</span>
                        </div>
                        <div class="progress-bar-linear-wrap">
                          <div class="progress-bar-linear"></div>
                        </div>
                      </article>
                    </div>
                    <div class="progress-linear-outer wow-outer">
                      <!-- Linear progress bar-->
                      <article class="progress-linear">
                        <div class="progress-header">
                          <p>Spanish</p><span class="progress-value">75</span>
                        </div>
                        <div class="progress-bar-linear-wrap">
                          <div class="progress-bar-linear"></div>
                        </div>
                      </article>
                    </div>
                    <div class="wow-outer button-outer"><a class="button button-md button-default button-winona wow slideInUp" href="">Learn more</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="cell-lg-6 height-fill">
            <div class="figure-card">
              <div class="figure-card-sizer"></div><img src="<?php echo e(url('/')); ?>/frontend/images/large-features-4-1214x792.jpg" alt="" width="1214" height="792"/>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-lg">
        <div class="container">
          <div class="row row-50 justify-content-lg-between flex-lg-row-reverse offset-top-1">
            <div class="col-lg-7 col-xl-6">
              <div class="heading-decorate-wrap">
                <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">F</span><span class="heading-decorate-main">Opening languages to everyone</span></h3>
                <!-- Bootstrap collapse-->
                <div class="card-group-custom card-group-corporate wow-outer" id="accordion2" role="tablist" aria-multiselectable="false">
                  <!--Bootstrap card-->
                  <article class="card card-custom wow fadeInDown" data-wow-delay=".05s">
                    <div class="card-header" role="tab">
                      <div class="card-title"><a id="accordion2-card-head-fkfutyjm" data-toggle="collapse" data-parent="#accordion2" href="#accordion2-card-body-lxekxbgl" aria-controls="accordion2-card-body-lxekxbgl" aria-expanded="true" role="button">
                          <div class="card-arrow"></div></a></div>
                    </div>
                    <div class="collapse show" id="accordion2-card-body-lxekxbgl" aria-labelledby="accordion2-card-head-fkfutyjm" data-parent="#accordion2" role="tabpanel">
                      <div class="card-body">
                        <p>We have been offering human translation services for the last 20 years to our 201,684 clients, in 187 languages and 40 areas of expertise. Our experts use a powerful combination of human creativity and machine intelligence to craft consistent quality translations at speed. At Verbonix, we also pride ourselves in being considered one of the best companies to work with by translators. We pay them rapidly and fairly, wherever they are in the world. Our team aims to seed and nurture solutions for today and design the ones for tomorrow. New workflows, new languages, new tools to build a service that helps shorten distances and make our planet a little smaller.</p>
                      </div>
                    </div>
                  </article>
                  <!--Bootstrap card-->
                  <article class="card card-custom wow fadeInDown" data-wow-delay=".1s">
                    <div class="card-header" role="tab">
                      <div class="card-title"><a class="collapsed" id="accordion2-card-head-qwyixxaa" data-toggle="collapse" data-parent="#accordion2" href="#accordion2-card-body-morsvyod" aria-controls="accordion2-card-body-morsvyod" aria-expanded="false" role="button">
                          <div class="card-arrow"></div></a></div>
                    </div>
                    <div class="collapse" id="accordion2-card-body-morsvyod" aria-labelledby="accordion2-card-head-qwyixxaa" data-parent="#accordion2" role="tabpanel">
                      <div class="card-body">
                        <p>We work with all standard editable formats such as doc, docx, ppt, pptx, xls, xlsx, odt, xml, html, idml, etc. We also have no problem with PDF format, and we will advise about non-editable and numerous lesser-known formats. If you have text in an editable format, we recommend that you send that one to get a quote. We will prepare a quote for you promptly and accurately. If you order a translation in a non-editable format and you want the graphical layout to be identical to the source, our graphical (desktop publishing) equipment is at no extra charge.</p>
                      </div>
                    </div>
                  </article>
                  <!--Bootstrap card-->
                  <article class="card card-custom wow fadeInDown" data-wow-delay=".15s">
                    <div class="card-header" role="tab">
                      <div class="card-title"><a class="collapsed" id="accordion2-card-head-xsmadcyp" data-toggle="collapse" data-parent="#accordion2" href="#accordion2-card-body-llraeaqm" aria-controls="accordion2-card-body-llraeaqm" aria-expanded="false" role="button">
                          <div class="card-arrow"></div></a></div>
                    </div>
                    <div class="collapse" id="accordion2-card-body-llraeaqm" aria-labelledby="accordion2-card-head-xsmadcyp" data-parent="#accordion2" role="tabpanel">
                      <div class="card-body">
                        <p>The price of a translation is based on the volume of standard pages, the language combination, the deadline, and whether standard or certified translation. It is due to these multiple factors that we don’t display prices on our website – because such price list would be more misleading than helpful.</p>
                      </div>
                    </div>
                  </article>
                  <!--Bootstrap card-->
                  <article class="card card-custom wow fadeInDown" data-wow-delay=".2s">
                    <div class="card-header" role="tab">
                      <div class="card-title"><a class="collapsed" id="accordion2-card-head-kjjctgrb" data-toggle="collapse" data-parent="#accordion2" href="#accordion2-card-body-ukkcjjkg" aria-controls="accordion2-card-body-ukkcjjkg" aria-expanded="false" role="button">
                          <div class="card-arrow"></div></a></div>
                    </div>
                    <div class="collapse" id="accordion2-card-body-ukkcjjkg" aria-labelledby="accordion2-card-head-kjjctgrb" data-parent="#accordion2" role="tabpanel">
                      <div class="card-body">
                        <p>After the source text has been analysed and you have accepted the quote, the translation will immediately start. The quote will also include the deadline for the completed document. We can fulfil the most demanding requirements for deadlines; just let us know that you need an express delivery. Generally speaking a translator can translate eight standard pages per day.</p>
                      </div>
                    </div>
                  </article>
                </div>
              </div>
            </div>
            <div class="col-lg-5 wow-outer"><img class="wow slideInLeft" src="<?php echo e(url('/')); ?>/frontend/images/accordions-1-470x368.jpg" alt="" width="470" height="368"/>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-lg text-center bg-primary-gradient">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-sm-10 col-md-12">
              <div class="box-cta-thin">
                <h3 class="wow-outer"><span class="wow slideInRight"><span class="font-weight-light">Professional</span> Translation services</span></h3>
                <div class="wow-outer button-outer"><a class="button button-secondary button-winona wow slideInLeft" href="">order now</a></div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- 3 Column Layout-->
      <section class="section section-lg text-center">
        <div class="container">
          <div class="heading-decorate-wrap text-center">
            <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">T</span><span class="heading-decorate-main">Testimonials</span></h3>
          </div>
          <!-- Owl Carousel-->
          <div class="owl-carousel wow fadeIn" data-items="1" data-md-items="2" data-lg-items="3" data-dots="true" data-nav="false" data-loop="true" data-margin="30" data-stage-padding="0" data-mouse-drag="false">
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-3-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Albert Webb</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Verbonix is made up of friendly and helpful people. What I most appreciated is their team. They are very competent and kind. In fact, they were ready to reply in detail to every question.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>I’m delighted to be working with Verbonix. Their team turns around projects on time and with accuracy taking into account the context. All their projects have been delivered on time.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>This company has been an integral part of our company’s success. They have provided outstanding solutions for both technical translation and corporate English courses.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-5-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Bill Warner</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Verbonix is our go-to partner for translation services. Whether it is French or Japanese, we know that we receive high-quality translations.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Your team provides some of the best English & German learning courses for corporate clients. The lessons aren’t only affordable but also highly useful to me and my colleagues.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>This translation bureau has been an integral part of our company’s success. They thoroughly understand the technical language and terminology required for our work.</p>
              </div>
            </blockquote>
          </div>
        </div>
      </section>
      <section class="section bg-gray-100 section-buba section-lg">
        <div class="container">
          <div class="row section-buba-row justify-content-center row-40">
            <div class="col-lg-8 col-xl-6">
              <div class="heading-decorate-wrap">
                <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">C</span><span class="heading-decorate-main">Contact Us</span></h3>
                <!-- RD Mailform-->
                <form class="rd-form rd-mailform" data-form-output="form-output-global" data-form-type="contact" method="post" action="">
                  <div class="row row-10">
                    <div class="col-md-6 wow-outer">
                      <div class="form-wrap wow fadeSlideInUp">
                        <label class="form-label-outside" for="contact-first-name">First Name</label>
                        <input class="form-input" id="contact-first-name" type="text" name="name" data-constraints="@Required">
                      </div>
                    </div>
                    <div class="col-md-6 wow-outer">
                      <div class="form-wrap wow fadeSlideInUp">
                        <label class="form-label-outside" for="contact-last-name">Last Name</label>
                        <input class="form-input" id="contact-last-name" type="text" name="name" data-constraints="@Required">
                      </div>
                    </div>
                    <div class="col-md-6 wow-outer">
                      <div class="form-wrap wow fadeSlideInUp">
                        <label class="form-label-outside" for="contact-email">E-mail</label>
                        <input class="form-input" id="contact-email" type="email" name="email" data-constraints="@Email  @Required">
                      </div>
                    </div>
                    <div class="col-md-6 wow-outer">
                      <div class="form-wrap wow fadeSlideInUp">
                        <label class="form-label-outside" for="contact-phone">Phone</label>
                        <input class="form-input" id="contact-phone" type="text" name="phone" data-constraints="@PhoneNumber  @Required">
                      </div>
                    </div>
                    <div class="col-12 wow-outer">
                      <div class="form-wrap wow fadeSlideInUp">
                        <label class="form-label-outside" for="contact-message">Your Message</label>
                        <textarea class="form-input" id="contact-message" name="message" data-constraints="@Required"></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="group group-middle">
                    <div class="wow-outer">
                      <button class="button button-primary button-winona wow slideInRight" type="submit">Send Message</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div class="col-lg-8 col-xl-6 section-buba-col">
              <div class="section-buba-image"><img src="<?php echo e(url('/')); ?>/frontend/images/contact-big-1-874x742.jpg" alt="" width="874" height="742"/>
              </div>
            </div>
          </div>
        </div>
      </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/home-page.blade.php ENDPATH**/ ?>
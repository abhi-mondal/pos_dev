<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>


<section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(<?php echo e(url('/')); ?>/frontend/images/breadcrumbs-image-1.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Services</h6>
              <h1 class="heading-decorate heading-decorate-lg breadcrumbs-custom-title"><span class="heading-decorate-symbol font-weight-ubold">S</span><span class="heading-decorate-main">Single Service</span></h1>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.php">Home</a></li>
              <li><a href="services.php">Services</a></li>
              
            </ul>
          </div>
        </div>
      </section>
      <section class="section section-lg bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon fl-bigmug-line-user144 wow fadeIn"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown">Qualified Employees</h4>
                  <p class="wow fadeInUpSmall">Clabulare prareres, tanquam alter scutum. Cum victrix observare, omnes domuses perdere emeritis, noster vigiles.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon fl-bigmug-line-rectangular78 wow fadeIn" data-wow-delay=".1s"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown" data-wow-delay=".1s">Free Consultations</h4>
                  <p class="wow fadeInUpSmall" data-wow-delay=".1s">Cursuss resistere! Ubi est pius consilium? Nunquam perdere fermium. Cum poeta unda.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon fl-bigmug-line-checkmark14 wow fadeIn" data-wow-delay=".2s"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown" data-wow-delay=".2s">100% Guaranteed</h4>
                  <p class="wow fadeInUpSmall" data-wow-delay=".2s">Tuss peregrinationes, tanquam varius elevatus. Sunt abaculuses vitare clemens, placidus classises.</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
      <!-- About This Service-->
      <section class="section section-lg">
        <div class="container">
          <div class="row row-50 justify-content-center justify-content-lg-between flex-lg-row-reverse align-items-center">
            <div class="col-lg-6 col-xl-5">
              <div class="inset-right-3">
                <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">A</span><span class="heading-decorate-main">About This Service</span></h3>
                <h5>Sunt seculaes imitari placidus, peritus lixaes. Cum uria volare, omnes humani generises dignus dexter, salvus armariumes.</h5>
                <p>Canis clemens boreas est. Rumors mori! Poetas studere in ferox rugensis civitas! Heu, gratis zelus! Calceuss credere in cirpi! Rusticus, primus adelphiss rare transferre de domesticus, fatalis historia.</p><a class="button button-lg button-primary button-winona" href="about-us.html">Learn more</a>
              </div>
            </div>
            <div class="col-lg-6"><img class="img-responsive" src="<?php echo e(url('/')); ?>/frontend/images/s1.jpg" alt="" width="568" height="388"/>
            </div>
          </div>
        </div>
      </section>
      <!-- Pricing-->
      <section class="section section-lg bg-gray-100">
        <div class="container text-center">
          <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">P</span><span class="heading-decorate-main">Pricing</span></h3>
          <div class="row row-30">
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight">
                <h5 class="pricing-minimal-title"><a href="">Standard</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>49.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Sunt animalises prensionem pius, fatalis cliniases. Rumors favere in gandavum! Lamias sunt eras de ferox clinias.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight" data-wow-delay=".05s">
                <h5 class="pricing-minimal-title"><a href="">Professional</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>67.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Amors resistere, tanquam varius amicitia. Bubos peregrinatione! Nobilis mons acceleratrix anhelares equiso est.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight" data-wow-delay=".1s">
                <h5 class="pricing-minimal-title"><a href="">Ultimate</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>86.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Nunquam attrahendam abactor. Grandis, talis gloss hic fallere de salvus, secundus finis. Cum plasmator messis.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-md bg-primary-darker text-center">
        <div class="container">
          <div class="box-cta-1">
            <h3><span class="font-weight-light">We Offer Quality</span> Translation Services</h3><a class="button button-lg button-secondary button-winona" href="#">Free consultation</a>
          </div>
        </div>
      </section>
      <!-- Testimonials-->
      <section class="section section-lg text-center">
        <div class="container">
          <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">T</span><span class="heading-decorate-main">Testimonials</span></h3>
          <!-- Owl Carousel-->
          <div class="owl-carousel wow fadeIn" data-items="1" data-md-items="2" data-lg-items="3" data-dots="true" data-nav="false" data-loop="true" data-margin="30" data-stage-padding="0" data-mouse-drag="false">
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-3-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Albert Webb</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Raptus, peritus adelphiss aegre imperium de velox, secundus competition. Hippotoxota de gratis ignigena, imperium liberi! Capio de talis historia, visum galatae! Vae, clemens magister! Salvus, fidelis fidess vix gratia de grandis, placidus bursa.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Zeluss nocere in secundus brema! Abnoba teres spatii est. Nunquam talem calceus. Cum pulchritudine observare, omnes accentores prensionem camerarius, lotus repressores. Lotus, talis equisos vix transferre de emeritis, domesticus nixus!</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt adelphises visum salvus, superbus galataees. Zeluss sunt gloss de bassus habena. Est gratis decor, cesaris. Azureus, fidelis abnobas interdum acquirere de raptus, noster fortis.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-5-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Bill Warner</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt repressores dignus bi-color, fortis particulaes. Sunt navises quaestio germanus, bassus gemnaes. Ignigenas sunt pulchritudines de camerarius calcaria. Albus messor mechanice experientias nuptia est.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt adelphises visum salvus, superbus galataees. Zeluss sunt gloss de bassus habena. Est gratis decor, cesaris. Azureus, fidelis abnobas interdum acquirere de raptus, noster fortis.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Zeluss nocere in secundus brema! Abnoba teres spatii est. Nunquam talem calceus. Cum pulchritudine observare, omnes accentores prensionem camerarius, lotus repressores. Lotus, talis equisos vix transferre de emeritis, domesticus nixus!</p>
              </div>
            </blockquote>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/services.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-warning" style="height:143px;">
                            <div class="inner">
                                <?php 
                                $connection=mysqli_connect("localhost","aictsol1_carlist","Pg=a&76[9%KA","aictsol1_carlisting_api_db_details");
                                $querr="SELECT * FROM myapis";
                                $querr_run=mysqli_query($connection,$querr);
                                //$result=mysqli_fetch_assoc($querr_run);
                                // 
                                while($row9 = mysqli_fetch_assoc($querr_run))
                                {
                                    $result9[]=$row9;
                                }
                                $userss=(sizeof($result9));
                                ?>
                                <h3><?php echo $userss; ?></h3>
                                <p style="font-size:20px;">User Registrations</p>
                            </div>
                           
                            
                        </div>
                    </div>
                     <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info" style="height:143px;">
                            <div class="inner">
                                <?php 
                                $connection=mysqli_connect("localhost","aictsol1_carlist","Pg=a&76[9%KA","aictsol1_carlisting_api_db_details");
                                $querr91="SELECT * FROM cardetails";
                                $querr_run91=mysqli_query($connection,$querr91);
                                //$result=mysqli_fetch_assoc($querr_run);
                                // 
                                while($row91 = mysqli_fetch_assoc($querr_run91))
                                {
                                    $result91[]=$row91;
                                }
                                $userss91=(sizeof($result91));
                                ?>
                                <h3><?php echo $userss91; ?></h3>
                                <p style="font-size:20px;">Total Posted Car</p>
                            </div>
                           
                            
                        </div>
                    </div>
                     <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success" style="height:143px;">
                            <div class="inner">
                                <?php 
                                $connection=mysqli_connect("localhost","aictsol1_carlist","Pg=a&76[9%KA","aictsol1_carlisting_api_db_details");
                                $querr4="SELECT * FROM payment2";
                                $querr_run4=mysqli_query($connection,$querr4);
                                //$result=mysqli_fetch_assoc($querr_run);
                                // 
                                while($row4 = mysqli_fetch_assoc($querr_run4))
                                {
                                    $result4[]=$row4;
                                }
                                $userss4=(sizeof($result4));
                                ?>
                                <h3><?php echo $userss4; ?></h3>
                                <p style="font-size:20px;">Total Payments</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-inr"></i>
                            </div>
                            
                        </div>
                    </div>
                    <!-- ./col -->
                    
                    <!-- ./col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/dashboard/dashboard.blade.php ENDPATH**/ ?>
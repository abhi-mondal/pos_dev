<?php $__env->startSection('title', 'List Payment'); ?>
<?php $__env->startSection('content'); ?>
<?php 
 $connection=mysqli_connect("localhost","aictsol1_carlist","Pg=a&76[9%KA","aictsol1_carlisting_api_db_details");
?>
    <div class="content-wrapper">
       
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Payment Management</h1>
                    </div>
                   
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin::dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Payment</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <?php if(Session::has('flash_message_error')): ?>
                                    <div class="alert alert-error alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong><?php echo session('flash_message_error'); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('flash_message_success')): ?>
                                    <div class="alert alert-success alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong><?php echo session('flash_message_success'); ?></strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Full Name</th>
                                        <th>User Id</th>
                                        <th>Amount</th>
                                        <th>Payment Type</th>
                                        <th>Transaction Id</th>
                                        <th>Order Id</th>
                                        <th>Transaction Time</th>
                                        <th>Modified On</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                       

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($getuser)): ?>
                                        <?php $i=0; ?>
                                        <?php $__currentLoopData = $getuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++; ?>
                                            <tr>
                                                <?php 
                                                $userid=$data->user_id;
                                                 
                                                   $querr99="SELECT * FROM myapis Where id=$userid";
                                                     //print_r($querr99);die();
                                $querr_run99=mysqli_query($connection,$querr99);
                                $row99 = mysqli_fetch_assoc($querr_run99);
                               // print_r($row99);
                              
                                                
                                                ?>
                                                
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo $row99['authorized_person_name']; ?></td>
                                                <td><?php echo e($data->user_id); ?></td>
                                                <td><?php echo e($data->paid_amount); ?></td>
                                                 <td><?php echo e($data->payment_method); ?></td>
                                                  <td><?php echo e($data->trans_id); ?></td>
                                                  <td><?php echo e($data->order_id); ?></td>
                                                  
                                                <td><?php echo e($data->created_at); ?></td>
                                                <td><?php echo e($data->updated_at); ?></td>
                                               
                                                <td>
                                                    <?php if($data->status == 'successful'): ?>
                                                       <i class="fa fa-check" style="color:green;" aria-hidden="true"></i>
                                                    <?php else: ?>
                                                       <i class="fa fa-times" style="color:red;" aria-hidden="true"></i>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    
                                                    <a href="<?php echo e(route('admin::delete_payment',['id' => $data->id])); ?>" class="btn btn-danger" role="button"><i class="fas fa-trash"></i></a>
                                                   
                                                </td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                         <th>Sl No</th>
                                        <th>Full Name</th>
                                        <th>User Id</th>
                                        <th>Amount</th>
                                        <th>Payment Type</th>
                                        <th>Transaction Id</th>
                                        <th>Order Id</th>
                                        <th>Transaction Time</th>
                                        <th>Modified On</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                       
                                    </tr>
                                    
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>

    <div class="modal fade" id="modal-sm">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Please Select Button</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are You Delete This Record! ?</p>
                </div>
                <div class="modal-footer justify-content-between">
                    <a href="" class="btn btn-default" data-dismiss="modal">No</a>
                    <a href="" id="delroute" class="btn btn-primary">Yes</a>
                </div>
            </div>
            
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
   

    <?php $__env->startPush('scripts'); ?>
        <script>
            var Inactive='Inactive';
            var Active='Active';
            function status(id,status) {
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route('admin::user_status')); ?>',
                    data: {
                        _token: '<?php echo csrf_token();?>',
                        id: id,
                        status: status
                    },
                    success: function (data) {
                        var resp = JSON.parse(data);
                        $('#status' + resp.id).html(resp.html);
                        $(document).find('.child #status'+resp.id).html(resp.html);
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aictsol1/carlisting.api.aictsolution.com/resources/views/Admin/pages/payment/view.blade.php ENDPATH**/ ?>
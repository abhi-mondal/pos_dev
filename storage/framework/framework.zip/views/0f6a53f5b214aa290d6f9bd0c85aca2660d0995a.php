


<script src="/cdn-cgi/apps/head/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script><link rel="icon" href="images/favicon.png" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu:300,700,800%7COswald:300,400,500">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/frontend/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/frontend/css/fonts.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/frontend/css/style.css" id="main-styles-link">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/elements/headercss.blade.php ENDPATH**/ ?>
<footer class="section footer-linked bg-primary-gradient">
        <div class="footer-linked-main">
          <div class="container">
            <div class="row row-50">
              <div class="col-lg-8">
                <h5 class="text-uppercase font-weight-bold">Quick Links</h5>
                <hr class="offset-right-1">
                <div class="row row-20">
                  <div class="col-6 col-sm-3">
                    <ul class="list list-xs">
                      <li><a href="">Services</a></li>
                      <li><a href="">Single Service</a></li>
                      <li><a href="">Contacts</a></li>
                      <li><a href="#">Testimonials</a></li>
                      <li><a href="">Privacy Policy</a></li>
                    </ul>
                  </div>
                  <div class="col-6 col-sm-3">
                    <ul class="list list-xs">
                      <li><a href="">Blog</a></li>
                      <li><a href="">About Us</a></li>
                      <li><a href="#">Team Member Page</a></li>
                      <li><a href="#">Single Project</a></li>
                      <li><a href="#">Login Page</a></li>
                    </ul>
                  </div>
                  <div class="col-6 col-sm-3">
                    <ul class="list list-xs">
                      <li><a href="">Careers</a></li>
                      <li><a href="">Portfolio</a></li>
                      <li><a href="#">News</a></li>
                      <li><a href="#">Our History</a></li>
                      <li><a href="">Single Job</a></li>
                    </ul>
                  </div>
                  <div class="col-6 col-sm-3">
                    <ul class="list list-xs">
                      <li><a href="#">Facebook</a></li>
                      <li><a href="#">Twitter</a></li>
                      <li><a href="#">Instagram</a></li>
                      <li><a href="#">LinkedIn</a></li>
                      <li><a href="#">Pinterest</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-7 col-lg-4">
                <h5 class="text-uppercase font-weight-bold">Contact Information</h5>
                <hr>
                <ul class="list-sm">
                  <li class="object-inline"><span class="icon icon-md mdi mdi-map-marker text-gray-700"></span><a class="link-default" href="#">demo, demo <br>demo</a></li>
                  <li class="object-inline"><span class="icon icon-md mdi mdi-phone text-gray-700"></span>
                    <ul class="list-0">
                      <li><a class="link-default" href="tel:#">xxxxxxxxxx</a></li>
                      <li><a class="link-default" href="tel:#">xxxxxxxxxx</a></li>
                    </ul>
                  </li>
                  <li class="object-inline"><span class="icon icon-md mdi mdi-email-outline text-gray-700"></span><a class="link-default" href="mailto:#">demo</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-linked-aside">
          <div class="container">
            <!-- Rights-->
            <p>Copyright © 2021. All Right Reserved . Designed & Developed by <a href="https://iwebnext.com">Iwebnext</a> </p>
          </div>
        </div>
      </footer><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/elements/footer.blade.php ENDPATH**/ ?>
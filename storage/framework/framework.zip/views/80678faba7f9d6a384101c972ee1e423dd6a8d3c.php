<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>

<section class="section section-lg bg-gray-100">
      <section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(<?php echo e(url('/')); ?>/frontend/images/breadcrumbs-image-1.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Pricing</h6>
              <h1 class="heading-decorate heading-decorate-lg breadcrumbs-custom-title"><span class="heading-decorate-symbol font-weight-ubold">S</span><span class="heading-decorate-main">Pricing</span></h1>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('pricing')); ?>">pricing</a></li>
              
            </ul>
          </div>
        </div>
      </section>
        <div class="container text-center">
          <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">P</span><span class="heading-decorate-main">Pricing</span></h3>
          <div class="row row-30">
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight">
                <h5 class="pricing-minimal-title"><a href="">Standard</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>49.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Sunt animalises prensionem pius, fatalis cliniases. Rumors favere in gandavum! Lamias sunt eras de ferox clinias.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight" data-wow-delay=".05s">
                <h5 class="pricing-minimal-title"><a href="">Professional</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>67.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Amors resistere, tanquam varius amicitia. Bubos peregrinatione! Nobilis mons acceleratrix anhelares equiso est.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Pricing Minimal-->
              <article class="pricing-minimal wow slideInRight" data-wow-delay=".1s">
                <h5 class="pricing-minimal-title"><a href="">Ultimate</a></h5>
                <p class="pricing-minimal-price"><span class="pricing-minimal-price-currency">$</span>86.00</p>
                <div class="pricing-minimal-divider"></div>
                <p>Nunquam attrahendam abactor. Grandis, talis gloss hic fallere de salvus, secundus finis. Cum plasmator messis.</p><a class="button button-primary button-winona" href="single-service.html">Order Now</a>
              </article>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-md bg-primary-darker text-center">
        <div class="container">
          <div class="box-cta-1">
            <h3><span class="font-weight-light">We Offer Quality</span> Translation Services</h3><a class="button button-lg button-secondary button-winona" href="#">Free consultation</a>
          </div>
        </div>
      </section>
      <!-- Testimonials-->
      <section class="section section-lg text-center">
        <div class="container">
          <h3 class="heading-decorate"><span class="heading-decorate-symbol font-weight-ubold">T</span><span class="heading-decorate-main">Testimonials</span></h3>
          <!-- Owl Carousel-->
          <div class="owl-carousel wow fadeIn" data-items="1" data-md-items="2" data-lg-items="3" data-dots="true" data-nav="false" data-loop="true" data-margin="30" data-stage-padding="0" data-mouse-drag="false">
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-3-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Albert Webb</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Raptus, peritus adelphiss aegre imperium de velox, secundus competition. Hippotoxota de gratis ignigena, imperium liberi! Capio de talis historia, visum galatae! Vae, clemens magister! Salvus, fidelis fidess vix gratia de grandis, placidus bursa.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Zeluss nocere in secundus brema! Abnoba teres spatii est. Nunquam talem calceus. Cum pulchritudine observare, omnes accentores prensionem camerarius, lotus repressores. Lotus, talis equisos vix transferre de emeritis, domesticus nixus!</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt adelphises visum salvus, superbus galataees. Zeluss sunt gloss de bassus habena. Est gratis decor, cesaris. Azureus, fidelis abnobas interdum acquirere de raptus, noster fortis.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-5-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Bill Warner</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt repressores dignus bi-color, fortis particulaes. Sunt navises quaestio germanus, bassus gemnaes. Ignigenas sunt pulchritudines de camerarius calcaria. Albus messor mechanice experientias nuptia est.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-2-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Harold Barnett</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Sunt adelphises visum salvus, superbus galataees. Zeluss sunt gloss de bassus habena. Est gratis decor, cesaris. Azureus, fidelis abnobas interdum acquirere de raptus, noster fortis.</p>
              </div>
            </blockquote>
            <blockquote class="quote-classic">
              <div class="quote-classic-meta">
                <div class="quote-classic-avatar"><img src="<?php echo e(url('/')); ?>/frontend/images/testimonials-person-1-96x96.jpg" alt="" width="96" height="96"/>
                </div>
                <div class="quote-classic-info">
                  <cite class="quote-classic-cite">Kelly McMillan</cite>
                  <p class="quote-classic-caption">Regular Client</p>
                </div>
              </div>
              <div class="quote-classic-text">
                <p>Zeluss nocere in secundus brema! Abnoba teres spatii est. Nunquam talem calceus. Cum pulchritudine observare, omnes accentores prensionem camerarius, lotus repressores. Lotus, talis equisos vix transferre de emeritis, domesticus nixus!</p>
              </div>
            </blockquote>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/pricing.blade.php ENDPATH**/ ?>
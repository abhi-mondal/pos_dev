<?php $__env->startSection('title', 'Update User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Slider Management</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item">All Slider</li>
                            <li class="breadcrumb-item active">Update Slider</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <?php if(Session::has('flash_message_error')): ?>
                                <div class="alert alert-error alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_error'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('flash_message_success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <h3 class="card-title">Update Slide</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start --> 
                            <form role="form" action="<?php echo e(route('admin::update_slider')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <div class="card-body">
                                    <div class="col-sm-12">
                                       
                                        <div class="form-group <?php echo e($errors->has('price')? 'has-error':''); ?>">
                                            <label>Name</label>
                                            <input type="text" name="price" class="form-control" value="<?php echo e($details->name); ?>">
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        </div>

                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group <?php echo e($errors->has('Upload Your Brabds Logo')? 'has-error':''); ?>">
                                            <label>Upload Your Slidere </label>
                                            <input type="file" name="file" class="form-control" >
                                            <span class="text-danger"><?php echo e($errors->first('Upload Your Banner Image')); ?></span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Update slider</button>
                                    <a href="<?php echo e(route('admin::view_slider')); ?>"><button type="button" class="btn btn-success">Back</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    <div class="content-wrapper">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoadmin\resources\views/Admin/pages/slider/edit.blade.php ENDPATH**/ ?>
<style>
  span.rd-navbar-submenu-toggle {
    display: none;
}
  </style>

<header class="section page-header">

          <!-- RD Navbar-->
          <div class="rd-navbar-wrap">
            <nav class="rd-navbar rd-navbar-minimal rd-navbar-minimal-wide" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-fixed" data-xxl-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
              <div class="rd-navbar-main-outer">
                <div class="rd-navbar-main">
                  <!-- RD Navbar Panel-->
                  <div class="rd-navbar-panel">
                    <!-- RD Navbar Toggle-->
                    <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                    <!-- RD Navbar Brand--><a class="rd-navbar-brand" href="<?php echo e(route('index')); ?>"> <h2>Logo</h2></a>
                  </div>
                  <div class="rd-navbar-main-element">
                    <div class="rd-navbar-nav-wrap">
                      <!-- RD Navbar Nav-->
                      <ul class="rd-navbar-nav">
                        <li class="rd-nav-item active"><a class="rd-nav-link" href="<?php echo e(route('index')); ?>">Home</a>
                        </li>
                        <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo e(route('about')); ?>">About Us</a>
                        </li>
                        <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo e(route('services')); ?>">Services<i class="fa fa-caret-down" aria-hidden="true"></i></a>
                          <!-- RD Navbar Dropdown-->
                          <ul class="rd-menu rd-navbar-dropdown">
                            <li class=""><a class="rd-dropdown-link" href="<?php echo e(route('translator')); ?>">translator</a></li>
                          </ul>
                        </li>
                        <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo e(route('pricing')); ?>">pricing</a>
                        
                          <!-- RD Navbar Dropdown-->
                         
                        </li>
                      
                          <!-- RD Navbar Megamenu-->
                          
                            </li>
                           
                        <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo e(route('contact')); ?>">Contacts</a>
                        </li>
                        <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo e(route('blog')); ?>">Blog</a>
                        </li>
                      </ul>
                    </div>
                    <!-- RD Navbar Search-->
                    <div class="rd-navbar-search" id="rd-navbar-search-1">
                      <button class="rd-navbar-search-toggle rd-navbar-fixed-element-2" data-rd-navbar-toggle="#rd-navbar-search-1"><span><i class="fa fa-search" aria-hidden="true"></i></span></button>
                      <form class="rd-search" action="" data-search-live="rd-search-results-live-1" method="GET">
                        <div class="form-wrap">
                          <label class="form-label" for="rd-navbar-search-form-input-1">Search...</label>
                          <input class="form-input rd-navbar-search-form-input" id="rd-navbar-search-form-input-1" type="text" name="s" autocomplete="off">
                          <div class="rd-search-results-live" id="rd-search-results-live-1"></div>
                        </div>
                        <button class="rd-search-form-submit fa-search" type="submit"></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        </header><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/elements/header.blade.php ENDPATH**/ ?>
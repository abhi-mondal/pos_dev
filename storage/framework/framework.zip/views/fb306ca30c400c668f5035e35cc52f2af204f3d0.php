<?php $__env->startSection('title', 'List User'); ?>
<?php $__env->startSection('content'); ?>

<section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(<?php echo e(url('/')); ?>/frontend/images/breadcrumbs-image-1.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Blog</h6>
              <h1 class="heading-decorate heading-decorate-lg breadcrumbs-custom-title"><span class="heading-decorate-symbol font-weight-ubold">G</span><span class="heading-decorate-main">Grid Blog</span></h1>
            </div>
            <ul class="breadcrumbs-custom-path">
            <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
              <li class="active">Grid Blog</li>
            </ul>
          </div>
        </div>
      </section>
      <section class="section section-lg">
        <div class="container">
          <div class="row row-50 row-xxl-70">
            <div class="col-md-6 scaleFadeInWrap">
              <!-- Post Modern-->
              <div class="wow scaleFadeIn">
                <article class="post-modern"><a class="post-modern-media" href=""><img src="<?php echo e(url('/')); ?>/frontend/images/b1.jpg" alt="" width="571" height="353"/></a>
                  <h4 class="post-modern-title"><a href="">Business Outlook – Languages To Know In 2021</a></h4>
                  <ul class="post-modern-meta">
                    <li>by Theresa Barnes</li>
                    <li>
                      <time datetime="2021">Apr 21, 2021 at 12:05 pm</time>
                    </li>
                    <li><a class="button-winona" href="#">News</a></li>
                  </ul>
                  <p>resistere semper ducunt ad velox cobaltum. varius domus etiam falleres calcaria est. eheu. abnoba, turpis, et accentor. exemplars sunt exsuls de primus lacta. cum luna ortum...</p>
                </article>
              </div>
            </div>
            <div class="col-md-6 scaleFadeInWrap">
              <!-- Post Modern-->
              <div class="wow scaleFadeIn" data-wow-delay=".1s">
                <article class="post-modern"> <a class="post-modern-media" href=""><img src="<?php echo e(url('/')); ?>/frontend/images/b2.jpg" alt="" width="571" height="353"/></a>
                  <h4 class="post-modern-title"><a href="">7 Reasons to Study English in Class</a></h4>
                  <ul class="post-modern-meta">
                    <li>by Theresa Barnes</li>
                    <li>
                      <time datetime="2021">Apr 21, 2021 at 12:05 pm</time>
                    </li>
                    <li><a class="button-winona" href="#">News</a></li>
                  </ul>
                  <p>Est ferox lixa, cesaris. Devirginatos congregabo! Pol, a bene acipenser. Est ferox navis, cesaris. Sunt absolutioes fallere clemens, fatalis lamiaes. Regius, bi-color accolas...</p>
                </article>
              </div>
            </div>
            <div class="col-md-6 scaleFadeInWrap">
              <!-- Post Modern-->
              <div class="wow scaleFadeIn">
                <article class="post-modern"><a class="post-modern-media" href=""><img src="<?php echo e(url('/')); ?>/frontend/images/b3.jpg" alt="" width="571" height="353"/></a>
                  <h4 class="post-modern-title"><a href="">Are Professional Translators Creative?</a></h4>
                  <ul class="post-modern-meta">
                    <li>by Theresa Barnes</li>
                    <li>
                      <time datetime="2021">Apr 21, 2021 at 12:05 pm</time>
                    </li>
                    <li><a class="button-winona" href="#">News</a></li>
                  </ul>
                  <p>Galluss persuadere! ecce. a falsis, axona barbatus danista. pess nocere in emeritis avenio! domesticus mortem patienter contactuss clinias est. velox, emeritis adelphiss...</p>
                </article>
              </div>
            </div>
            <div class="col-md-6 scaleFadeInWrap">
              <!-- Post Modern-->
              <div class="wow scaleFadeIn" data-wow-delay=".1s">
                <article class="post-modern"><a class="post-modern-media" href=""><img src="<?php echo e(url('/')); ?>/frontend/images/b4.jpg" alt="" width="571" height="353"/></a>
                  <h4 class="post-modern-title"><a href="blog.php">Improving Your Company’s Image With Translation Services</a></h4>
                  <ul class="post-modern-meta">
                    <li>by Theresa Barnes</li>
                    <li>
                      <time datetime="2021">Apr 21, 2021 at 12:05 pm</time>
                    </li>
                    <li><a class="button-winona" href="#">News</a></li>
                  </ul>
                  <p>Cur fortis resistere? Voxs ortum in hafnia! Fraticinida, nixus, et pars. Audax nix aliquando experientias sensorem est. Est magnum valebat, cesaris. Vae, hilotae! Flavum...</p>
                </article>
              </div>
            </div>
          </div>
          <div class="pagination">
            <div class="page-item active"><a class="page-link button-winona" href="#">1</a></div>
            <div class="page-item"><a class="page-link button-winona" href="#">2</a></div>
            <div class="page-item"><a class="page-link button-winona" href="#">3</a></div>
            <div class="page-item"><a class="page-link button-winona" href="#">4</a></div>
          </div>
        </div>
      </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translater\resources\views/Frontend/pages/blog.blade.php ENDPATH**/ ?>